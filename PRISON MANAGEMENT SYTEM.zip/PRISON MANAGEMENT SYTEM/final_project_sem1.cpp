#include <iostream>
#include <string>
using namespace std;
// Structure to represent an inmate
struct Inmate {
    int inmateid;
    string inmatename;
    int inmateage;
    string inmatecrime;
    string inmatesentence;
    string inmatereleasedate;
    int aggressiveness;   // Aggressiveness level (0-10)
    int followingInstructions;  // Ability to follow instructions (0-10)
    int behaviorWithOthers;  // Behavior towards other inmates (0-10)
    string cellType;  // Type of cell assigned
    int behaviorScore;  // Calculated behavior score
    int cellNumber;  // Assigned cell number
    bool medicalCare;  // Requires medical care
    int daysUntilRelease; // Used to view how many days until release
};
// Structure to represent a visitor
struct Visitor {
    int visitorID; // Unique identifier for visitor
    string visitorName; // Name of the visitor
    int visitorAge;  // Age of the visitor
    string purpose;  // Purpose of the visit
};
// Function prototypes
void initializeInmates(Inmate inmates[]);
void viewInmateRecord(Inmate inmates[], int totalInmates);
void addInmateRecord(Inmate inmates[], int &totalInmates, int maxInmates);
void alterInmateRecord(Inmate inmates[], int totalInmates);
void viewBehaviorStats(Inmate inmates[], int totalInmates);
bool adminMenu(Inmate inmates[], int &totalInmates, int maxInmates);
bool wardenMenu(Inmate inmates[], int totalInmates);
void initializeVisitors(Visitor visitors[], int &totalVisitors);
void viewVisitorRecords(Visitor visitors[], int totalVisitors);
void addVisitorRecord(Visitor visitors[], int &totalVisitors, int maxVisitors);
void allocateCells(Inmate inmates[], int totalInmates);
bool staffMenu(Inmate inmates[], int totalInmates);
void viewUpcomingReleases(Inmate inmates[], int totalInmates);
void viewTotalInmates(int totalInmates);
void prepareReleaseDocumentation(Inmate inmates[], int totalInmates);

const int maxVisitors = 7; // Maximum visitors the system can handle
const int totalCells = 15; // Total number of cells
int main() {
    const int maxInmates = 100;
    Inmate inmates[maxInmates];
    int totalInmates = 10;
    initializeInmates(inmates);

    while (true) {
        int user;
        cout << "ENTER USERNAME (1 for Admin, 2 for Staff, 3 for Warden, 0 to Exit): ";
        cin >> user;

        if (user == 0) {
            cout << "Exiting the system. Goodbye!" << endl;
            break;
        }
 // Get password from user
        string password;
        string adminPassword = "iamanadmin";
        string staffPassword = "iamastaff";
        string wardenPassword = "iamawarden";

        switch (user) {
            case 1: // admin password
                cout << "ENTER PASSWORD: ";
                cin >> password;
                if (password == adminPassword) {
                    cout << "WELCOME TO THE PMS SYSTEM. YOU HAVE LOGGED IN AS THE ADMIN." << endl;
                    if (!adminMenu(inmates, totalInmates, maxInmates)) {
                        break;
                    }
                } else {
                    cout << "INVALID CREDENTIALS. TRY AGAIN." << endl;
                }
                break;
            case 2:   // staff password
                cout << "ENTER PASSWORD: ";
                cin >> password;
                if (password == staffPassword) {
                    cout << "WELCOME TO THE PMS SYSTEM. YOU HAVE LOGGED IN AS THE STAFF MEMBER." << endl;
                    if (!staffMenu(inmates, totalInmates)) {
                        break;
                    }
                } else {
                    cout << "INVALID CREDENTIALS. TRY AGAIN." << endl;
                }
                break;
            case 3:   // warden password
                cout << "ENTER PASSWORD: ";
                cin >> password;
                if (password == wardenPassword) {
                    cout << "WELCOME TO THE PMS SYSTEM. YOU HAVE LOGGED IN AS THE WARDEN." << endl;
                    if (!wardenMenu(inmates, totalInmates)) {
                        break;
                    }
                } else {
                    cout << "INVALID CREDENTIALS. TRY AGAIN." << endl;
                }
                break;
            default:
                cout << "INVALID USER TYPE. TRY AGAIN." << endl;
        }
    }
    return 0;
}
// Initializes the inmates array with sample data

void initializeInmates(Inmate inmates[]) {
    inmates[0] = {1, "Donald Trump", 78, "Every single crime possible", "Life Sentence", "22 November 2033", 5, 8, 6, "Medical/mental care unit", 4, 9, false, 780};
    inmates[1] = {2, "Benjamin Netanyahu", 37, "Genocide", "Death sentence", "19 December 2029", 9, 6, 4, "High-risk Security cell", 0, 3, false, 0};
    inmates[2] = {3, "Luigi Mangioni", 26, "Manslaughter", "2 months in prison", "24 January 2027", 7, 7, 5, "Low-risk Security Cell", 28, 1, false, 60};
    inmates[3] = {4, "Sean Combs", 55, "Pedophilia", "10 years in prison", "18 November 2035", 6, 5, 3, "Medical/mental care unit", 14, 5, true, 4567};
    inmates[4] = {5, "Jeffrey Dahmer", 34, "Serial Killing", "Death Sentence", "16 June 2027", 10, 4, 2, "High-risk Security cell", 2, 2, true, 2900};
    inmates[5] = {6, "Kamala Harris", 60, "Bombings in Syria and Iraq", "Life Sentence", "20 July 2065", 8, 5, 4, "High-risk Security cell", 5, 10, false, 0};
    inmates[6] = {7, "Jack Horrid", 67, "Car robbery", "10 years in prison", "25 October 2035", 5, 7, 6, "Low-risk Security Cell", 18, 6, false, 910};
    inmates[7] = {8, "Robert Coleman", 36, "Abuse", "5 years in prison", "17 August 2030", 4, 9, 7, "Medical/mental care unit", 14, 7, false, 540};
    inmates[8] = {9, "Joshua Max", 28, "Smuggling drugs", "30 years in prison", "3 September 2055", 6, 6, 5, "Low-risk Security Cell", 22, 8, false, 6500};
    inmates[9] = {10, "Mira Carl", 33, "Newborn kidnapping", "35 years in prison", "30 March 2070", 7, 5, 5, "Medical/mental care unit", 11, 2, true, 6790};
}
// Function to view behavior stats of an inmate
void viewBehaviorStats(Inmate inmates[], int totalInmates) {
    int inmateID;
    cout << "Enter the inmate ID to view behavior statistics: ";
    cin >> inmateID;

    bool found = false;
    for (int i = 0; i < totalInmates; i++) {
        if (inmates[i].inmateid == inmateID) {
            found = true;
            cout << "Behavior statistics for inmate " << inmateID << ":\n";
            cout << "Name: " << inmates[i].inmatename << endl;
            cout << "Age: " << inmates[i].inmateage << endl;
            cout << "Crime: " << inmates[i].inmatecrime << endl;
            cout << "Aggressiveness: " << inmates[i].aggressiveness << "/10\n";
            cout << "Following Instructions: " << inmates[i].followingInstructions << "/10\n";
            cout << "Behavior with Others: " << inmates[i].behaviorWithOthers << "/10\n";
            break;
        }
    }

    if (!found) {
        cout << "No behavior statistics found for inmate ID " << inmateID << "." << endl;
    }
}
// Admin menu function
bool adminMenu(Inmate inmates[], int &totalInmates, int maxInmates) {
    int choice;
    do {
        cout << "\n--- Admin Menu ---" << endl;
        cout << "1. View Inmate Record" << endl;
        cout << "2. Add Inmate Record" << endl;
        cout << "3. Alter Inmate Record" << endl;
        cout << "4. Logout" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                viewInmateRecord(inmates, totalInmates);
                break;
            case 2:
                addInmateRecord(inmates, totalInmates, maxInmates);
                break;
            case 3:
                alterInmateRecord(inmates, totalInmates);
                break;
            case 4:
                return false;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (true);
}

bool wardenMenu(Inmate inmates[], int totalInmates) {
    int choice;
    do {
        cout << "\n--- Warden Menu ---" << endl;
        cout << "1. View Behavior Statistics" << endl;
        cout << "2. View Upcoming Release Dates" << endl;
        cout << "3. View Total Inmates" << endl;
        cout << "4. Prepare Release Documentation" << endl; 
        cout << "5. Logout" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                viewBehaviorStats(inmates, totalInmates);
                break;
            case 2:
                viewUpcomingReleases(inmates, totalInmates);
                break;
            case 3:
                viewTotalInmates(totalInmates); 
                break;
            case 4:
                prepareReleaseDocumentation(inmates, totalInmates);   
                break;
            case 5:
                return false;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (true);
}


void initializeVisitors(Visitor visitors[], int &totalVisitors);
void viewVisitorRecords(Visitor visitors[], int totalVisitors);
void addVisitorRecord(Visitor visitors[], int &totalVisitors, int maxVisitors);

bool staffMenu(Inmate inmates[], int totalInmates) {
    Visitor visitors[maxVisitors];
    int totalVisitors = 0;
    initializeVisitors(visitors, totalVisitors);

    int choice;
    do {
        cout << "\n--- Staff Menu ---" << endl;
        cout << "1. View Visitor Records" << endl;
        cout << "2. Add Visitor Record" << endl;
        cout << "3. View Inmate Cell Assignments" << endl;
        cout << "4. Allocate Cells" << endl;
        cout << "5. Logout" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                viewVisitorRecords(visitors, totalVisitors);
                break;
            case 2:
                addVisitorRecord(visitors, totalVisitors, maxVisitors);
                break;
            case 3:
                // View inmate cell assignments
                cout << "\n--- Inmate Cell Assignments ---" << endl;
                for (int i = 0; i < totalInmates; ++i) {
                    cout << "Inmate ID: " << inmates[i].inmateid
                         << ", Cell Number: "
                         << (inmates[i].cellNumber == -1 ? "Not Assigned" : to_string(inmates[i].cellNumber))
                         << endl;
                }
                break;

            case 4:
                // Allocate cells
                cout << "\nAllocating cells based on behavior and medical needs...\n";
                allocateCells(inmates, totalInmates);
                cout << "Cell allocation completed.\n";
                break;

            case 5:
                cout << "Logging out." << endl;
                return false;
            default:
                cout << "Invalid choice. Try again." << endl;
        }
    } while (true);
}
// Function to view inmate record
void viewInmateRecord(Inmate inmates[], int totalInmates) {
    if (totalInmates == 0) {
        cout << "No inmates are currently recorded in the system." << endl;
        return;
    }

    int choice;
    cout << "\n--- View Inmate Records ---" << endl;
    cout << "1. View all inmate records" << endl;
    cout << "2. View a specific inmate record" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    if (choice == 1) {
        cout << "\n--- All Inmate Records ---" << endl;
        for (int i = 0; i < totalInmates; i++) {
            cout << "\nInmate ID: " << inmates[i].inmateid << endl;
            cout << "Name: " << inmates[i].inmatename << endl;
            cout << "Age: " << inmates[i].inmateage << endl;
            cout << "Crime: " << inmates[i].inmatecrime << endl;
            cout << "Sentence: " << inmates[i].inmatesentence << endl;
            cout << "Release Date: " << inmates[i].inmatereleasedate << endl;
            cout << "Aggressiveness: " << inmates[i].aggressiveness << "/10" << endl;
            cout << "Following Instructions: " << inmates[i].followingInstructions << "/10" << endl;
            cout << "Behavior with Others: " << inmates[i].behaviorWithOthers << "/10" << endl;
        }
    } else if (choice == 2) {
        int inmateID;
        cout << "Enter the inmate ID to view: ";
        cin >> inmateID;

        bool found = false;
        for (int i = 0; i < totalInmates; i++) {
            if (inmates[i].inmateid == inmateID) {
                found = true;
                cout << "\n--- Inmate Record ---" << endl;
                cout << "Inmate ID: " << inmates[i].inmateid << endl;
                cout << "Name: " << inmates[i].inmatename << endl;
                cout << "Age: " << inmates[i].inmateage << endl;
                cout << "Crime: " << inmates[i].inmatecrime << endl;
                cout << "Sentence: " << inmates[i].inmatesentence << endl;
                cout << "Release Date: " << inmates[i].inmatereleasedate << endl;
                cout << "Aggressiveness: " << inmates[i].aggressiveness << "/10" << endl;
                cout << "Following Instructions: " << inmates[i].followingInstructions << "/10" << endl;
                cout << "Behavior with Others: " << inmates[i].behaviorWithOthers << "/10" << endl;
                cout << "Cell Type: " << inmates[i].cellType << endl;
                break;
            }
        }
        if (!found) {
            cout << "No record found for inmate ID " << inmateID << "." << endl;
        }
    } else {
        cout << "Invalid choice. Please try again." << endl;
    }
}


void addInmateRecord(Inmate inmates[], int &totalInmates, int maxInmates) {
    if (totalInmates >= maxInmates) {
        cout << "Cannot add more inmates. Maximum capacity reached!" << endl;
        return;
    }

    Inmate newInmate;
    cout << "Enter details for the new inmate:\n";
    cout << "Inmate ID: ";
    cin >> newInmate.inmateid;
    cin.ignore(); // Clear input buffer
    cout << "Name: ";
    getline(cin, newInmate.inmatename);
    cout << "Age: ";
    cin >> newInmate.inmateage;
    cin.ignore(); // Clear input buffer
    cout << "Crime: ";
    getline(cin, newInmate.inmatecrime);
    cout << "Sentence: ";
    getline(cin, newInmate.inmatesentence);
    cout << "Release Date: ";
    getline(cin, newInmate.inmatereleasedate);
    cout << "Aggressiveness (0-10): ";
    cin >> newInmate.aggressiveness;
    cout << "Following Instructions (0-10): ";
    cin >> newInmate.followingInstructions;
    cout << "Behavior with Others (0-10): ";
    cin >> newInmate.behaviorWithOthers;

    // Add the new inmate to the array
    inmates[totalInmates++] = newInmate;
    cout << "Inmate added successfully!\n";
}

// function for altering inmate records
void alterInmateRecord(Inmate inmates[], int totalInmates) {
    int inmateID;
    cout << "Enter the ID of the inmate to alter: ";
    cin >> inmateID;

    bool found = false;
    for (int i = 0; i < totalInmates; i++) {
        if (inmates[i].inmateid == inmateID) {
            found = true;
            cout << "Current details of inmate " << inmateID << ":\n";
            cout << "Name: " << inmates[i].inmatename << endl;
            cout << "Age: " << inmates[i].inmateage << endl;
            cout << "Crime: " << inmates[i].inmatecrime << endl;
            cout << "Sentence: " << inmates[i].inmatesentence << endl;
            cout << "Release Date: " << inmates[i].inmatereleasedate << endl;
            cout << "Aggressiveness: " << inmates[i].aggressiveness << "/10\n";
            cout << "Following Instructions: " << inmates[i].followingInstructions << "/10\n";
            cout << "Behavior with Others: " << inmates[i].behaviorWithOthers << "/10\n";

            cin.ignore(); // Clear input buffer
            string input;

            cout << "\nEnter new details (leave blank to keep current):\n";

            cout << "Name (" << inmates[i].inmatename << "): ";
            getline(cin, input);
            if (!input.empty()) inmates[i].inmatename = input;

            cout << "Age (" << inmates[i].inmateage << "): ";
            getline(cin, input);
            if (!input.empty()) inmates[i].inmateage = stoi(input);

            cout << "Crime (" << inmates[i].inmatecrime << "): ";
            getline(cin, input);
            if (!input.empty()) inmates[i].inmatecrime = input;

            cout << "Sentence (" << inmates[i].inmatesentence << "): ";
            getline(cin, input);
            if (!input.empty()) inmates[i].inmatesentence = input;

            cout << "Release Date (" << inmates[i].inmatereleasedate << "): ";
            getline(cin, input);
            if (!input.empty()) inmates[i].inmatereleasedate = input;

            cout << "Aggressiveness (" << inmates[i].aggressiveness << "): ";
            getline(cin, input);
            if (!input.empty()) inmates[i].aggressiveness = stoi(input);

            cout << "Following Instructions (" << inmates[i].followingInstructions << "): ";
            getline(cin, input);
            if (!input.empty()) inmates[i].followingInstructions = stoi(input);

            cout << "Behavior with Others (" << inmates[i].behaviorWithOthers << "): ";
            getline(cin, input);
            if (!input.empty()) inmates[i].behaviorWithOthers = stoi(input);

            cout << "Inmate record updated successfully!\n";
            break;
        }
    }

    if (!found) {
        cout << "No inmate found with ID " << inmateID << ".\n";
    }
}
//initialize visitor records
void initializeVisitors(Visitor visitors[], int &totalVisitors) {
    // Predefined visitors
    visitors[0] = {1, "Alice Johnson", 45, "Meeting with inmate ID 3"};
    visitors[1] = {2, "Bob Smith", 38, "Delivering documents"};
    visitors[2] = {3, "Carla Gomez", 29, "Family visit for inmate ID 5"};
    totalVisitors = 3;
}
// input records for new visitors
void viewVisitorRecords(Visitor visitors[], int totalVisitors) {
    if (totalVisitors == 0) {
        cout << "No visitors recorded in the system." << endl;
        return;
    }

    cout << "\n--- Visitor Records ---" << endl;
    for (int i = 0; i < totalVisitors; i++) {
        cout << "\nVisitor ID: " << visitors[i].visitorID << endl;
        cout << "Name: " << visitors[i].visitorName << endl;
        cout << "Age: " << visitors[i].visitorAge << endl;
        cout << "Purpose: " << visitors[i].purpose << endl;
    }
}
// function to add records for new visitors
void addVisitorRecord(Visitor visitors[], int &totalVisitors, int maxVisitors) {
    if (totalVisitors >= maxVisitors) {
        cout << "Maximum visitor capacity reached. Cannot add more records." << endl;
        return;
    }

    int id = totalVisitors + 1; // Auto-generate visitor ID
    string name, purpose;
    int age;

    cout << "\nEnter visitor name: ";
    cin.ignore();
    getline(cin, name);

    cout << "Enter visitor age: ";
    cin >> age;

    cout << "Enter purpose of visit: ";
    cin.ignore();
    getline(cin, purpose);

    visitors[totalVisitors] = {id, name, age, purpose};
    totalVisitors++;

    cout << "Visitor record added successfully!" << endl;
}
// function to allocate cells to the inmates according to their behaviour
void allocateCells(Inmate inmates[], int totalInmates) {
    const int totalHighRiskCells = 5;   // High-risk cells for inmates with low behavior scores
    const int totalMedicalCells = 5;   // Medical/mental cells for inmates with medium behavior scores
    const int totalLowRiskCells = 5;   // Low-risk cells for inmates with high behavior scores

    bool highRiskAssigned[totalHighRiskCells] = {false};
    bool medicalAssigned[totalMedicalCells] = {false};
    bool lowRiskAssigned[totalLowRiskCells] = {false};

    for (int i = 0; i < totalInmates; ++i) {
        cout << "Inmate ID: " << inmates[i].inmateid
             << ", Behavior Score: " << inmates[i].behaviorScore
             << ", Medical Care: " << (inmates[i].medicalCare ? "Yes" : "No") << "\n"; 

        if (inmates[i].behaviorScore < 7) {
            // Assign to high-risk cells
            for (int j = 0; j < totalHighRiskCells; ++j) {
                if (!highRiskAssigned[j]) {
                    inmates[i].cellNumber = j + 1; // Cell numbers start from 1
                    inmates[i].cellType = "High Risk";
                    highRiskAssigned[j] = true;
                    cout << "Assigned to High-Risk Cell: " << inmates[i].cellNumber << "\n";
                    break;
                }
            }
        } else if (inmates[i].behaviorScore >= 7 && inmates[i].behaviorScore <= 15) {
            // Assign to medical/mental cells
            for (int j = 0; j < totalMedicalCells; ++j) {
                if (!medicalAssigned[j]) {
                    inmates[i].cellNumber = j + 1; // Cell numbers start from 1
                    inmates[i].cellType = "Medical";
                    medicalAssigned[j] = true;
                    cout << "Assigned to Medical Cell: " << inmates[i].cellNumber << "\n";
                    break;
                }
            }
        } else {
            // Assign to low-risk cells
            for (int j = 0; j < totalLowRiskCells; ++j) {
                if (!lowRiskAssigned[j]) {
                    inmates[i].cellNumber = j + 1; // Cell numbers start from 1
                    inmates[i].cellType = "Low Risk";
                    lowRiskAssigned[j] = true;
                    cout << "Assigned to Low-Risk Cell: " << inmates[i].cellNumber << "\n";
                    break;
                }
            }
        }

        if (inmates[i].cellNumber == 0) {
            cout << "No available cell for inmate ID " << inmates[i].inmateid << ".\n";
        }
    }
}
// function for release date alerts
void viewUpcomingReleases(Inmate inmates[], int totalInmates) {
    cout << "\n--- Upcoming Release Dates ---" << endl;
    bool hasReleases = false;
    for (int i = 0; i < totalInmates; ++i) {    // Assuming release dates are in a valid format (as strings)
        if (!inmates[i].inmatereleasedate.empty()) {
            cout << "Inmate: " << inmates[i].inmatename << ", Release Date: " << inmates[i].inmatereleasedate << endl;
            hasReleases = true;
        }
    }
    if (!hasReleases) {
        cout << "No upcoming releases available." << endl;
    } 
}            //function for alert of release dates

void viewTotalInmates(int totalInmates) {
    cout << "\nTotal Inmates Currently Present: " << totalInmates << endl;  //for finding total number of inmates
}
void prepareReleaseDocumentation(Inmate inmates[], int totalInmates) {
    int daysUntilRelease;
    cout << "\nEnter the number of days until release to generate documentation: ";
    cin >> daysUntilRelease;

    cout << "\n--- Release Documentation ---" << endl;
    bool found = false;
    for (int i = 0; i < totalInmates; i++) {
        // Assuming `daysUntilRelease` is an attribute in the `Inmate` structure
        if (inmates[i].daysUntilRelease <= daysUntilRelease) {
            cout << "ID: " << inmates[i].inmateid << ", Name: " << inmates[i].inmatename 
                 << ", Release in: " << inmates[i].daysUntilRelease << " days" << endl;
            found = true;
        }
    }

    if (!found) {
        cout << "No inmates found for release within the specified timeframe.\n";
    }
}

