
## 🎯 Purpose
This project is aimed at beginners to practice core C++ programming concepts in a real-world simulation.

## 👨‍💻 Author
*Shafia Asad*

## 📄 License
This project is for educational purposes only.
